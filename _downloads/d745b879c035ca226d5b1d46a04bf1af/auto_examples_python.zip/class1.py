'''
Class1 use example
==================

Well this is just an illustration.
'''

from __future__ import print_function
from sample_module.mod1 import Class1

c = Class1()
r = c.a_method(1., 2., 3)
print(r)

